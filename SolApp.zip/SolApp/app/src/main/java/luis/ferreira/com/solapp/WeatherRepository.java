package luis.ferreira.com.solapp;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class WeatherRepository {

    private static final String WEATHER_TYPE_URL = "http://api.ipma.pt/open-data/weather-type-classe.json";
    private static final String DISTRICTS_URL = "http://api.ipma.pt/open-data/distrits-islands.json";
    private static final String WEATHER_DAILY_PATTERN_URL = "http://api.ipma.pt/open-data/forecast/meteorology/cities/daily/hp-daily-forecast-day0.json";

    private WeatherDao mWeatherDao;
    private RequestQueue queue;

    private JSONObject weather_types_response;
    private JSONObject districts_response;
    private JSONObject weather_info_response;

    WeatherRepository(Application application) {
        Log.d(WeatherRepository.class.getSimpleName(),"Constructing Repo!");
        WeatherDatabase db = WeatherDatabase.getDatabase(application);
        queue = Volley.newRequestQueue(application);
        mWeatherDao = db.weatherDao();
    }

    LiveData<WeatherData> getWeatherData(String district) {
        //Refresh data using volley
        refreshData();
        return mWeatherDao.getByDistrict(district);
    }

    private void refreshData() {
        getWeatherTypes();
    }

    private void getWeatherTypes() {
        JsonObjectRequest weather_type_request = new JsonObjectRequest(Request.Method.GET,
                WEATHER_TYPE_URL,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("DEBUGGING LINE",response.toString());
                        weather_types_response = response;
                        getDistricts();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("DEBUGGING LINE","Bad Stuff Happened!");
                    }
                });
        queue.add(weather_type_request);
    }

    private void getDistricts() {
        JsonObjectRequest districts_request = new JsonObjectRequest(Request.Method.GET,
                DISTRICTS_URL,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("DEBUGGING LINE",response.toString());
                        districts_response = response;
                        getWeatherInfo();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("DEBUGGING LINE","Bad Stuff Happened!");
                    }
                });
        queue.add(districts_request);
    }

    private void getWeatherInfo() {
        JsonObjectRequest weather_daily_request = new JsonObjectRequest(Request.Method.GET,
                WEATHER_DAILY_PATTERN_URL,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("DEBUGGING LINE",response.toString());
                        weather_info_response = response;
                        updateDB();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("DEBUGGING LINE","Bad Stuff Happened!");
                    }
                });
        queue.add(weather_daily_request);
    }

    private void updateDB() {
        Log.d("DEGUGGING LINE","Updating DB");
        JSONArray array = weather_info_response.optJSONArray("data");
        for(int i = 0; i < array.length(); i++) {
            JSONObject object = array.optJSONObject(i);
            String weather_type = findWeatherTypeById(object.optInt("idWeatherType"));
            String district_name = findDistrictByGlobalIdLocal(object.optInt("globalIdLocal"));
            int min_temperature = object.optInt("tMin");
            int max_temperature = object.optInt("tMax");
            WeatherData weatherData = new WeatherData(district_name,weather_type,min_temperature,max_temperature);
            Log.d("DEBUGGING LINE", weatherData.toString());
            insert(weatherData);
        }
    }

    private String findWeatherTypeById(int id) {
        JSONArray array = weather_types_response.optJSONArray("data");
        for (int i = 0; i < array.length(); i++) {
            JSONObject object = array.optJSONObject(i);
            if (object.optInt("idWeatherType") == id) {
                return object.optString("descIdWeatherTypeEN");
            }
        }
        return "unknown";
    }

    private String findDistrictByGlobalIdLocal(int id) {
        JSONArray array = districts_response.optJSONArray("data");
        for (int i = 0; i < array.length(); i++) {
            JSONObject object = array.optJSONObject(i);
            if (object.optInt("globalIdLocal") == id) {
                return object.optString("local");
            }
        }
        return "unknown";
    }

    public void insert (WeatherData weatherData) {
        new insertAsyncTask(mWeatherDao).execute(weatherData);
    }

    private static class insertAsyncTask extends AsyncTask<WeatherData, Void, Void> {

        private WeatherDao mAsyncTaskDao;

        insertAsyncTask(WeatherDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final WeatherData... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }
}
