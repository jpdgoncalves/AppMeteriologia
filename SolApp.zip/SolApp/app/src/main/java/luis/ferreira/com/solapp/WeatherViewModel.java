package luis.ferreira.com.solapp;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;
import android.util.Log;

public class WeatherViewModel extends AndroidViewModel {

    private WeatherRepository weatherRepository;

    public WeatherViewModel(@NonNull Application application) {
        super(application);
        Log.d(WeatherViewModel.class.getSimpleName(),"Constructing Model!");
        weatherRepository = new WeatherRepository(application);
    }

    public LiveData<WeatherData> getWeatherData(String district) {
        Log.d(WeatherViewModel.class.getSimpleName(),"Retrieving Data!");
        return weatherRepository.getWeatherData(district);
    }
}
