package luis.ferreira.com.solapp;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener {

    private Spinner districts;
    private TextView weather_state;
    private TextView min_temperature;
    private TextView max_temperature;

    private ArrayAdapter<CharSequence> adapter;

    private WeatherViewModel weatherViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        districts = (Spinner) findViewById(R.id.districts);
        weather_state = (TextView) findViewById(R.id.weather_state);
        min_temperature = (TextView) findViewById(R.id.min_temperature);
        max_temperature = (TextView) findViewById(R.id.max_temperature);

        adapter = ArrayAdapter.createFromResource(this,
                R.array.districts_labels, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner.
        if (districts != null) {
            districts.setOnItemSelectedListener(this);
            districts.setAdapter(adapter);
        }

        districts.setSelection(10);

        weatherViewModel = ViewModelProviders.of(this).get(WeatherViewModel.class);
        weatherViewModel.getWeatherData("Lisboa").observe(this, new Observer<WeatherData>() {
            @Override
            public void onChanged(@Nullable WeatherData weatherData) {
                if(weatherData != null) {
                    weather_state.setText(weatherData.getWeather_state());
                    min_temperature.setText("Min Temperature : " + weatherData.getMin_temperature());
                    max_temperature.setText("Max Temperature : " + weatherData.getMax_temperature());
                }
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int
            i, long l) {
        Log.d("DEBUGGING LINE","Testing something");
        String district = adapterView.getItemAtPosition(i).toString();
        weatherViewModel.getWeatherData(district).observe(this, new Observer<WeatherData>() {
            @Override
            public void onChanged(@Nullable WeatherData weatherData) {
                if(weatherData != null) {
                    weather_state.setText(weatherData.getWeather_state());
                    min_temperature.setText("Min Temperature : " + weatherData.getMin_temperature());
                    max_temperature.setText("Max Temperature : " + weatherData.getMax_temperature());
                }
            }
        });
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
