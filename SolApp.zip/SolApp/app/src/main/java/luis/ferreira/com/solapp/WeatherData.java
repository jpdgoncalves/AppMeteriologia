package luis.ferreira.com.solapp;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;
import android.util.Log;

@Entity(tableName = "weather_data")
public class WeatherData {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "district")
    private String district = "Indefenido";
    private String weather_state = "Indefenido";
    private int min_temperature = -99;
    private int max_temperature = 99;


    public WeatherData(String district, String weather_state, int min_temperature, int max_temperature) {
        Log.d(WeatherData.class.getSimpleName(),"Constructing Data!");
        this.district = district;
        this.weather_state = weather_state;
        this.min_temperature = min_temperature;
        this.max_temperature = max_temperature;
    }

    @NonNull
    public String getDistrict() {
        return district;
    }

    public void setDistrict(@NonNull String district) {
        this.district = district;
    }

    public String getWeather_state() {
        return weather_state;
    }

    public void setWeather_state(String weather_state) {
        this.weather_state = weather_state;
    }

    public int getMin_temperature() {
        return min_temperature;
    }

    public void setMin_temperature(int min_temperature) {
        this.min_temperature = min_temperature;
    }

    public int getMax_temperature() {
        return max_temperature;
    }

    public void setMax_temperature(int max_temperature) {
        this.max_temperature = max_temperature;
    }

    @Override
    public String toString() {
        return "WeatherData{" +
                "district='" + district + '\'' +
                ", weather_state='" + weather_state + '\'' +
                ", min_temperature=" + min_temperature +
                ", max_temperature=" + max_temperature +
                '}';
    }
}
